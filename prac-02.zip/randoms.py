dir(str)
import random
dir(random)

import random
print(random.randint(5, 20))  # line 1 (largest number was 13)
print(random.randrange(3, 10, 2))  # line 2 (largest number was 7)
print(random.uniform(2.5, 5.5))  # line 3 (largest number was 3.0)