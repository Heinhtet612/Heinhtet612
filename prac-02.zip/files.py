def main():

    text = "Your name is Bob"
    text = text.lower()
    print(text)

main()