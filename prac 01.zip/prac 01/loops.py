for i in range(1, 21, 2):
    print(i, end=' ')
print()

for i in range(100, 0, -10):
    print(i)

for i in range(21, 0):
    print(i, end=' ')
    print()