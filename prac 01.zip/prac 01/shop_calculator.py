def main():
    print("Number of items : 3")
    item1 = int(input("Price of item :"))
    item2 = int(input("Price of item :"))
    item3 = int(input("Price of item :"))
    total = item1 + item2 + item3
    print("Total price for 3 items is:", total)

main()