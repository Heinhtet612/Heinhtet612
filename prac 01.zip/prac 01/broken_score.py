"""
CP1404/CP5632 - Practical
Broken program to determine score status
"""

# TODO: Fix this!

score = float(input("Enter score: "))
if 0 <= score > 100 :
    print("Invalid score")
elif 90 <= score < 100:
    print("Excellent")
elif 50 <= score < 89:
    print("Passable")
elif 0 < score < 49:
    print("Bad")
